
package com.example.gamelauncher;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.annotation.Nullable;

public class FPSOverlay extends Service {

    private WindowManager windowManager;
    private TextView fpsText;

    @Override
    public void onCreate() {
        super.onCreate();

        fpsText = new TextView(this);
        fpsText.setText("FPS: ~60");
        fpsText.setTextColor(Color.GREEN);
        fpsText.setTextSize(14);
        fpsText.setBackgroundColor(Color.argb(120, 0, 0, 0));
        fpsText.setPadding(10, 10, 10, 10);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                        WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 10;
        params.y = 10;

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.addView(fpsText, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (fpsText != null) windowManager.removeView(fpsText);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
