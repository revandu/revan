
package com.example.gamelauncher;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    Button btnBoost;
    ArrayList<ApplicationInfo> gameApps;
    ArrayList<String> gameNames;
    PackageManager pm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        btnBoost = findViewById(R.id.btnBoost);
        pm = getPackageManager();
        gameApps = new ArrayList<>();
        gameNames = new ArrayList<>();

        List<ApplicationInfo> allApps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for (ApplicationInfo app : allApps) {
            if ((app.flags & ApplicationInfo.FLAG_IS_GAME) != 0 || app.category == ApplicationInfo.CATEGORY_GAME) {
                gameApps.add(app);
                gameNames.add(pm.getApplicationLabel(app).toString());
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, gameNames);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            Intent launchIntent = pm.getLaunchIntentForPackage(gameApps.get(i).packageName);
            if (launchIntent != null) {
                startService(new Intent(MainActivity.this, FPSOverlay.class));
                startActivity(launchIntent);
            }
        });

        btnBoost.setOnClickListener(v -> {
            killBackgroundApps();
            Toast.makeText(this, "Booster Aktif!", Toast.LENGTH_SHORT).show();
        });
    }

    private void killBackgroundApps() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningApps = am.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo app : runningApps) {
            if (!app.processName.equals(getPackageName())) {
                am.killBackgroundProcesses(app.processName);
            }
        }
    }
}
